function con1(){
    let img1=document.querySelector('#inr')
    let img2=document.querySelector('#jap')
    let img3=document.querySelector('#usa')

    let ua2=document.querySelector('#dol')
    let ia2=document.querySelector('#pp')
    let jp2=document.querySelector('#yen')

    // let ua1=document.querySelector('#ua')
    // let ia1=document.querySelector('#ia')
    // let jp1=document.querySelector('#jp')

    let cont=document.querySelector('#con1').value
    if(cont=='india')
    {
        img1.style.display="block"
        img2.style.display="none"
        img3.style.display="none"

        // ia1.style.display="none";
        // ua1.style.display="block";
        // jp1.style.display="block";
        ia2.style.display="block"
        ua2.style.display="none"
        jp2.style.display="none"

    }
    else if(cont=='USA')
    {
        img1.style.display="none"
        img2.style.display="none"
        img3.style.display="block"

        // ua1.style.display="none";
        // ia1.style.display="block";
        // jp1.style.display="block";

        ia2.style.display="none"
        ua2.style.display="block"
        jp2.style.display="none"

    }
    else{
        
        img1.style.display="none"
        img2.style.display="block"
        img3.style.display="none"

        // jp1.style.display="none";
        // ia1.style.display="block";
        // ua1.style.display="block";

        ia2.style.display="none"
        ua2.style.display="none"
        jp2.style.display="block"

    }
}
function con2(){
    let img1=document.querySelector('#inr1')
    let img2=document.querySelector('#jap1')
    let img3=document.querySelector('#usa1')


    let ua2=document.querySelector('#dol1')
    let ia2=document.querySelector('#pp1')
    let jp2=document.querySelector('#yen1')

    // let ua=document.querySelector('#ua')
    // let ia=document.querySelector('#ia')
    // let jp=document.querySelector('#jp')

    // let ua1=document.querySelector('#ua')
    // let ia1=document.querySelector('#ia')
    // let jp1=document.querySelector('#jp')


    let cont=document.querySelector('#con2').value
    if(cont=='india')
    {
        img1.style.display="block"
        img2.style.display="none"
        img3.style.display="none"
        // ia.style.display="none";
        // ua.style.display="block";
        // jp.style.display="block";
        ia2.style.display="block"
        ua2.style.display="none"
        jp2.style.display="none"
        
    }
    else if(cont=='USA')
    {
        img1.style.display="none"
        img2.style.display="none"
        img3.style.display="block"
        // ua.style.display="none";
        // ia.style.display="block";
        // jp.style.display="block";
        ia2.style.display="none"
        ua2.style.display="block"
        jp2.style.display="none"
    }
    else{
        img1.style.display="none"
        img2.style.display="block"
        img3.style.display="none"

        // jp.style.display="none";
        // ia.style.display="block";
        // ua.style.display="block";
        ia2.style.display="none"
        ua2.style.display="none"
        jp2.style.display="block"
    }
}
function swap(){
    // let cont=document.querySelector('#con1').value
    // let cont1=document.querySelector('#con2').value
    // console.log('hi')
    // console.log(cont)
    // console.log(cont1)
    // let a=cont;
    // let b=cont1;
    // document.querySelector('#con1')=document.querySelector('#con2').value;;
    // cont1=document.querySelector('#con1').value;
    // cont=document.querySelector('#con2').value;

    


}
function display(){
    let input=document.querySelector('#input').value
    let cont=document.querySelector('#con1').value
    let cont1=document.querySelector('#con2').value
    console.log(input)
    if(cont=='USA' && cont1=='india')
    {
        let result = 84*input;
        let me=document.querySelector('#give').value
        console.log(result)
        document.querySelector('#give').value=result;
    }
    else if( cont=='USA' && cont1=='JAPAN')
        {
            let result = input*156.63;
            let me=document.querySelector('#give').value
            console.log(result)
            document.querySelector('#give').value=result;
        }
        else if( cont=='USA' && cont1=='USA')
            {
                let result = input;
                let me=document.querySelector('#give').value
                console.log(result)
                document.querySelector('#give').value=result;
            }
            // ----------------------------------inr-------------------------------------
        else if( cont=='india' && cont1=='USA')
        {
            let result = input/84;
            let me=document.querySelector('#give').value
            console.log(result)
            document.querySelector('#give').value=result;
        }
        else if( cont=='india' && cont1=='JAPAN')
            {
                let result = input*1.84;
                let me=document.querySelector('#give').value
                console.log(result)
                document.querySelector('#give').value=result;
            }
            else if( cont=='india' && cont1=='india')
                {
                    let result = input;
                    let me=document.querySelector('#give').value
                    console.log(result)
                    document.querySelector('#give').value=result;

                }
                // -----------------------------------------------japan------------------------------
                else if( cont=='JAPAN' && cont1=='USA')
                    {
                        let result = input*0.0064;
                        let me=document.querySelector('#give').value
                        console.log(result)
                        document.querySelector('#give').value=result;
                    }
                    else if( cont=='JAPAN' && cont1=='JAPAN')
                        {
                            let result = input;
                            let me=document.querySelector('#give').value
                            console.log(result)
                            document.querySelector('#give').value=result;
                        }
                        else if( cont=='JAPAN' && cont1=='india')
                            {
                                let result = input*0.54;
                                let me=document.querySelector('#give').value
                                console.log(result)
                                document.querySelector('#give').value=result;
                            }
}