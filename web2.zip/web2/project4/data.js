// Create an input element
let input = document.createElement('input');

// Set the type to radio
input.setAttribute('type', 'radio');

// Append the input element to the body
document.body.appendChild(input);