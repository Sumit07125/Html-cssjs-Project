

function copy(){
    document.querySelector('#input2').value=document.querySelector('#input').value;
    // b=a.toUpperCase();
    a=document.querySelector('#input').value;
    input=document.getElementById('input')
    input2=document.getElementById('input2')
    switch(a)
    {
        case 'pink': input.style.backgroundColor="pink"
                     input2.style.border="4px solid pink"
                     input2.style.borderRadius="20px"
                    break;
        case 'yellow': input.style.backgroundColor="yellow"
                    input2.style.border="4px solid yellow"
                    input2.style.borderRadius="20px"
                      break;
        case 'blue': input.style.backgroundColor="blue"
                        input2.style.border="4px solid blue"
                        input2.style.borderRadius="20px"
                    break;
        case 'red': input.style.backgroundColor="red"
                        input2.style.border="4px solid red"
                        input2.style.borderRadius="20px"
                    break;
        case 'green': input.style.backgroundColor="green"
                        input2.style.border="4px solid green"
                        input2.style.borderRadius="20px"
                    break;
        case 'black': input.style.backgroundColor="black"
                        input2.style.border="4px solid black"
                        input2.style.borderRadius="20px"
                    break;
        case 'orange': input.style.backgroundColor="orange"
                        input2.style.border="4px solid orange"
                        input2.style.borderRadius="20px"
                    break;
        case 'purple': input.style.backgroundColor="purple"
                        input2.style.border="4px solid purple"
                        input2.style.borderRadius="20px"
                    break;
        default : input.style.backgroundColor="white"
                    input2.style.border="1px solid black"
                    input2.style.borderRadius="0px"
    }
}
input2=document.getElementById('input2')
input=document.getElementById('input')
input3=document.getElementById('input3')
input4=document.getElementById('input4')




function copy2(){
    document.querySelector('#input4').value=document.querySelector('#input3').value;
}
function color(){
    input3=document.getElementById('input3')
    input3.style.backgroundColor="white"
    input3.style.color="black"
}
function color2(){
    input3=document.getElementById('input3')
    input3.style.backgroundColor="yellow"
    input3.style.color="red"
}
function color3(){
    input4.style.backgroundColor="white"
    input4.style.color="black"
}
function color4(){
    input4=document.getElementById('input4')
    input4.style.backgroundColor="yellow"
    input4.style.color="red"
}