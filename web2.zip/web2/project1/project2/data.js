cou=0
function count1(){
    cou=cou+1;
    console.log(cou)
    // document.getElementsByClassName('badge')=cou;
    document.querySelector(".badge").innerHTML=cou
}