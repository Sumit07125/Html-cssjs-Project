// let d=new Date();
// document.querySelector('.date').innerHTML=d
// let d=new Date()
// let div=document.createElement('div')
// div.innerText=d.toDateString()
// document.getElementById('sumit').appendChild(div)

function product() {
    category = document.querySelector("#ppr").value;

    let electronic = "Electronic";
    let grosery = "Grosery";


    let gro_item = document.querySelector("#gro-pro");
    let ele_item = document.querySelector("#ele-pro");
    let def_item = document.querySelector("#def-pro");
    let dis_none = document.querySelector("#none");
    let dis_ele = document.querySelector("#ele-dis");
    let dis_gro = document.querySelector("#gro-dis");
    let quantity = document.querySelector("#qua-text");
    let quantity_none = document.querySelector("#quantity");



    if (electronic == category) {
        gro_item.style.display = "none";
        def_item.style.display = "none";
        dis_ele.style.display = "block";
        dis_gro.style.display = "none";
        dis_none.style.display = "none";
        quantity.style.display = "block";
        quantity_none.style.display = "none";

    }
    else {
        gro_item.style.display = "block";
    }
    if (grosery == category) {
        ele_item.style.display = "none";
        def_item.style.display = "none";
        dis_gro.style.display = "block";
        dis_ele.style.display = "none";
        dis_none.style.display = "none";
        quantity.style.display = "block";
        quantity_none.style.display = "none";
    }
    else {
        ele_item.style.display = "block";
    }
}
function rate_ele() {

    let gro_item = document.querySelector("#gro-pro").value;
    let ele_item = document.querySelector("#ele-pro").value;
    let dis_rate = document.querySelector("#dis-rate");


    if (ele_item == "Fan") {
        dis_rate.value = 4500;
    } else if (ele_item == "Tv") {
        dis_rate.value = 24000;
    } else if (ele_item == "Charger") {
        dis_rate.value = 1200;
    }else {
        dis_rate.value = 2100; // Default value
    }
}


function rate_gro(){

    let gro_item = document.querySelector("#gro-pro").value;
    let ele_item = document.querySelector("#ele-pro").value;
    let dis_rate = document.querySelector("#dis-rate");


    if (gro_item == "Soan") {
        dis_rate.value = 75;
    } else if (gro_item == "Oil") {
        dis_rate.value = 200;
    } else if (gro_item == "Soap") {
        dis_rate.value = 50;
    }else {
        dis_rate.value = 69;
    }
}

function display(){
    let gro_item = document.querySelector("#gro-pro").value;
    let ele_item = document.querySelector("#ele-pro").value;
    let dis_ele = document.querySelector("#ele-dis").value;
    let dis_gro = document.querySelector("#gro-dis").value;
    let quantity = document.querySelector("#qua-text").value;
    category = document.querySelector("#ppr").value;
    let dis_rate = document.querySelector("#dis-rate").value;
    let total=null;

  let electronic = "Electronic";
    let grosery = "Grosery";

    dis_rate=dis_rate*quantity
   document.querySelector(".category_dis").innerHTML=category;
    
    document.querySelector(".quantity_dis").innerHTML=quantity;
    document.querySelector(".rate_dis").innerHTML=dis_rate;
    

    if(category=="Electronic")
    {
        document.querySelector(".product_dis").innerHTML=ele_item;
        document.querySelector(".discount_dis").innerHTML=dis_ele;
    }
    else if(category=="Grosery"){
        document.querySelector(".product_dis").innerHTML=gro_item;
        document.querySelector(".discount_dis").innerHTML=dis_gro;
    }
    else{
        alert('PLEASE SELECT ITEAM');
        document.querySelector(".invice").style.display="none"
    }
    


    if(category==grosery)
        {
            document.querySelector(".invice").style.display="block"
            if (gro_item == "Soan") {
                total=(quantity*75*90)/100;
                        document.querySelector(".tot_bil").innerHTML=total
            } else if (gro_item == "Oil") {
                total= (quantity*200*90)/100;
                document.querySelector(".tot_bil").innerHTML=total
            } else if (gro_item == "Soap") {
                total= (quantity*50*90)/100;
                        document.querySelector(".tot_bil").innerHTML=total
            }else {total= (quantity*70*90)/100;
                document.querySelector(".tot_bil").innerHTML=total
                console.log('hi')
            }




            
        }
    else 
        {document.querySelector(".invice").style.display="block"
   
            if (ele_item =="Fan") {
                total=(quantity*4500*95)/100;
                document.querySelector(".tot_bil").innerHTML=total
   
               } else if (ele_item =="Tv") {
                   total= (quantity*24000*95)/100;
                   document.querySelector(".tot_bil").innerHTML=total
               } else if (ele_item =="Charger") {
                   total= (quantity*1200*95)/100;
                document.querySelector(".tot_bil").innerHTML=total
               }else {
                   total= (quantity*2100*95)/100;
                   document.querySelector(".tot_bil").innerHTML=total
               }

    console.log(category);
    console.log(category);
    console.log(category);
}
}
